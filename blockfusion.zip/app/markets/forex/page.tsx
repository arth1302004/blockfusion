import { redirect } from "next/navigation"

export default function ForexPage() {
  redirect("/dashboard/markets/forex")
}
