import { redirect } from "next/navigation"

export default function MarketsPage() {
  redirect("/dashboard/markets")
}
